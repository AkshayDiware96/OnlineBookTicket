package com.OTBS.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Movies {

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int movie_id;
private String movie_name;
private int slots=0;
private String theatre;
private String cast;
private String image;


public int getMovie_id() {
	return movie_id;
}
public void setMovie_id(int movie_id) {
	this.movie_id = movie_id;
}
public String getMovie_name() {
	return movie_name;
}
public void setMovie_name(String movie_name) {
	this.movie_name = movie_name;
}
public int getSlots() {
	return slots;
}
public void setSlots(int slots) {
	this.slots = slots;
}
public String getTheatre() {
	return theatre;
}
public void setTheatre(String theatre) {
	this.theatre = theatre;
}
public String getCast() {
	return cast;
}
public void setCast(String cast) {
	this.cast = cast;
}
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}


	
	

}
