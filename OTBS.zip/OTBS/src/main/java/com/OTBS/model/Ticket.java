package com.OTBS.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Ticket {

@Id 
@GeneratedValue(strategy = GenerationType.IDENTITY)	
private int ticketid;
private String ticket_type;
private String cost;
public int getTicketid() {
	return ticketid;
}
public void setTicketid(int ticketid) {
	this.ticketid = ticketid;
}
public String getTicket_type() {
	return ticket_type;
}
public void setTicket_type(String ticket_type) {
	this.ticket_type = ticket_type;
}
public String getCost() {
	return cost;
}
public void setCost(String cost) {
	this.cost = cost;
}




}
