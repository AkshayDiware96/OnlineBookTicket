package com.OTBS.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Bookings {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int bookingid;
private String email;
private String ticket_type;
private String  seatnumber;
private String date;
private String time;
private int duration;
private String cost = "0";
private int movie_id;
private String slotid;
private int paid = 0;
private String movie_name = "";
private String showtime;

public int getBookingid() {
	return bookingid;
}
public void setBookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getTicket_type() {
	return ticket_type;
}
public void setTicket_type(String ticket_type) {
	this.ticket_type = ticket_type;
}


public String getSeatnumber() {
	return seatnumber;
}
public void setSeatnumber(String seatnumber) {
	this.seatnumber = seatnumber;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
public String getCost() {
	return cost;
}
public void setCost(String cost) {
	this.cost = cost;
}

public String getSlotid() {
	return slotid;
}
public void setSlotid(String slotid) {
	this.slotid = slotid;
}
public int getPaid() {
	return paid;
}
public void setPaid(int paid) {
	this.paid = paid;
}
public int getMovie_id() {
	return movie_id;
}
public void setMovie_id(int movie_id) {
	this.movie_id = movie_id;
}
public String getMovie_name() {
	return movie_name;
}
public void setMovie_name(String movie_name) {
	this.movie_name = movie_name;
}
public String getShowtime() {
	return showtime;
}
public void setShowtime(String showtime) {
	this.showtime = showtime;
}



}
