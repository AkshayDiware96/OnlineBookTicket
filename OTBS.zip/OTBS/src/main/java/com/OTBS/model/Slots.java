package com.OTBS.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Slots {

@Id
private String slotid;
private int movie_id;
private String slotno;
private int status = 0;
private int duration = 0;


public String getSlotid() {
	return slotid;
}
public void setSlotid(String slotid) {
	this.slotid = slotid;
}
public int getMovie_id() {
	return movie_id;
}
public void setMovie_id(int movie_id) {
	this.movie_id = movie_id;
}
public String getSlotno() {
	return slotno;
}
public void setSlotno(String slotno) {
	this.slotno = slotno;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}




}
