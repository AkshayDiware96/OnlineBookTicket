package com.OTBS.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OTBS.Service.TicketService;
import com.OTBS.model.Ticket;
import com.OTBS.repo.TicketRepo;

@Service
public class ticketServiceImpl implements TicketService {
	
	@Autowired
	private TicketRepo ticketrepo;

	public List<Ticket> listAll(){
		return ticketrepo.findAll();
	}
	
	public Ticket add(Ticket ticket){
		
		Ticket t =  this.ticketrepo.save(ticket);
		return t;
		}
	
	


	@Override
	public int getTicketCost(String ticket_type) {
		String cost = this.ticketrepo.getTicketCost(ticket_type);
		
		return Integer.parseInt(cost);
	}

}
