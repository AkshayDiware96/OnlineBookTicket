package com.OTBS.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OTBS.Service.UserService;
import com.OTBS.model.user;
import com.OTBS.repo.UserRepo;


@Service
public class userServiceImpl implements UserService{

	@Autowired
	private UserRepo userrepo;
	@Override
	public boolean createuser(user user) {
		// TODO Auto-generated method stub
		user u=this.userrepo.findByUsername(user.getUsername());
		if(u!=null) {
			System.out.println("Username Already Used");
			return false;
		}
		else {
			 u=this.userrepo.save(user);
		}
		return true;
	}

	
	@Override
	public user getuser(String username) {
		// TODO Auto-generated method stub
		return this.userrepo.findByUsername(username);
	}

	@Override
	public List<user> getalluser() {
		// TODO Auto-generated method stub
		return this.userrepo.findAll();
	}

	@Override
	public void deleteuser(int uid) {
		// TODO Auto-generated method stub
		this.userrepo.deleteById(uid);
		
	}

	@Override
	public user updateuser(user u) {
		// TODO Auto-generated method stub
		user t=this.userrepo.findByUid(u.getUid());
		t.setPassword(u.getPassword());
	
		user d=this.userrepo.save(t);
		return d;
	}

	@Override
	public user getuserbyid(int uid) {
		// TODO Auto-generated method stub
		return this.userrepo.findByUid(uid);
	}


	@Override
	public user getCurrentUser(String username) {
		// TODO Auto-generated method stub
		return this.userrepo.findByUsername(username);
	}

}
