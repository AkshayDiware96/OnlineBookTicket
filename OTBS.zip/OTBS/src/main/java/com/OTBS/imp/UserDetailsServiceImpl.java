package com.OTBS.imp;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.OTBS.model.user;
import com.OTBS.repo.UserRepo;

@Service
public class UserDetailsServiceImpl implements UserDetailsService{


	@Autowired
	private UserRepo userrepo;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
	
		  user u=this.userrepo.findByUsername(username);
		  System.out.println("user "+u);
		  if(u==null) {
			  System.out.println("User not found");
			  }
		  System.out.println("user "+u);
		
		 //return u;
		return new User(u.getUsername(),u.getPassword(),new ArrayList<>());
		
	}
	


}
