package com.OTBS.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OTBS.Service.MoviesService;
import com.OTBS.Service.SlotsService;
import com.OTBS.model.Bookings;
import com.OTBS.model.Slots;
import com.OTBS.repo.MoviesRepo;
import com.OTBS.repo.SlotsRepo;

@Service
public class slotsServiceImpl implements SlotsService{

@Autowired
private SlotsRepo slotsrepo;

@Autowired
private MoviesRepo moviesrepo;

@Autowired
private MoviesService movieservice;

	@Override
	public List<Slots> listAll() {
		// TODO Auto-generated method stub
		return this.slotsrepo.findAll();
	}

	@Override
	public boolean add(Slots slot) {
		// TODO Auto-generated method stub
		if (this.moviesrepo.existsById(slot.getMovie_id())) {
			if (this.slotsrepo.existsById(slot.getSlotid())) {
				return false;
			}
			else {
				
				this.slotsrepo.save(slot);
				this.movieservice.addSlot(slot.getMovie_id());
				return true;
			}
		}
		else {
			return false;
		}
	}

	@Override
	public List<Slots> slotById(int movieid) {
		// TODO Auto-generated method stub
		return this.slotsrepo.slotById(movieid);
	}

	
	  @Override 
	  public void updateSlot(Bookings booking) { 
		  // TODO Auto-generated method stub
		  this.slotsrepo.updateSlot(1, booking.getDuration(),booking.getSlotid());
	  
	  }
	 

	@Override
	public void rollbackSlot(String slotid) {
		// TODO Auto-generated method stub
		this.slotsrepo.rollbackSlot(slotid);
		
	}

	@Override
	public void deleteslot(String id) {
		// TODO Auto-generated method stub
		this.movieservice.reduceslot(id);
		this.slotsrepo.deleteById(id);
		
		
	}

}
