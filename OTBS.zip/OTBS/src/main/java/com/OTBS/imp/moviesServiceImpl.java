package com.OTBS.imp;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OTBS.Service.MoviesService;
import com.OTBS.model.Movies;
import com.OTBS.repo.MoviesRepo;


@Service
public class moviesServiceImpl implements MoviesService {

@Autowired
private MoviesRepo moviesrepo;	

	@Override
	public List<Movies> listAll() {
		// TODO Auto-generated method stub
		return this.moviesrepo.findAll();
	}

	@Override
	public boolean addMovie(Movies movie) {
		// TODO Auto-generated method stub
		int c=this.moviesrepo.findCountOfMovie(movie.getMovie_name());
		if (c>0) {
			return false;
		}
		else {
			this.moviesrepo.save(movie);
			return true;			
		}
		
	}

	@Override
	public void addSlot(int movieid) {
		// TODO Auto-generated method stub
		this.moviesrepo.updateSlot(movieid);
		
	}

	@Override
	public Movies getmovie(int movieid) {
		// TODO Auto-generated method stub
		return moviesrepo.findBymovie_id(movieid);
	}

	@Override
	public Movies updatemovie(Movies m) {
		Movies t=moviesrepo.findBymovie_id(m.getMovie_id());
		t.setCast(m.getCast());
		t.setImage(m.getImage());
		t.setMovie_name(m.getMovie_name());
		t.setTheatre(m.getTheatre());
	
		
		
		Movies r=this.moviesrepo.save(t);
		return r;
		
	}

	@Override
	public void reduceslot(String id) {
		// TODO Auto-generated method stub
		String s=id.substring(0,id.indexOf(" "));
		
		int i=Integer.parseInt(s);
		System.out.println("Movie id "+i);
		this.moviesrepo.deductslot(i);
		
	}

	

}
