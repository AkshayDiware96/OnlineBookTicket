package com.OTBS.imp;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OTBS.Service.BookingsService;
import com.OTBS.Service.MoviesService;
import com.OTBS.Service.SlotsService;
import com.OTBS.Service.TicketService;
import com.OTBS.model.Bookings;
import com.OTBS.repo.BookingsRepo;

@Service
public class bookingServiceImpl implements BookingsService {


	@Autowired
	private BookingsRepo bookingsrepo;
	
	@Autowired
	private SlotsService slotservice;
	
	@Autowired
	private TicketService ticketservice;
	
	private MoviesService moviesservice;
	
	
	@Override
	public Bookings add(Bookings booking) {
		// TODO Auto-generated method stub
		
		System.out.println("Before storing");
		
		Bookings currentBooking =  this.bookingsrepo.save(booking);	
		slotservice.updateSlot(booking);
		int duration = currentBooking.getDuration();
		
		

		
		  Bookings currBooking = currentBooking;
		  
		  currBooking.setDuration(duration);
		  
		  int vehicleCost =this.ticketservice.getTicketCost(currBooking.getTicket_type());
		  
		  int cost = duration*vehicleCost;
		  
		  currBooking.setCost(String.valueOf(cost));
		  
		  this.bookingsrepo.save(currBooking);
		 
		  return currentBooking;
		 
		
		
	}

	@Override
	public List<Bookings> listAll() {
		// TODO Auto-generated method stub
		return this.bookingsrepo.findAll();
	}

	@Override
	public List<Bookings> listByUsers(String email) {
		// TODO Auto-generated method stub
		return  this.bookingsrepo.listByUsers(email);
	}

	@Override
	public boolean endBooking(int bookingid) {
		// TODO Auto-generated method stub
this.bookingsrepo.endBooking(bookingid);
		
		
		
		int duration = this.bookingsrepo.findById(bookingid).get().getDuration();

		Bookings currentBooking = this.bookingsrepo.findById(bookingid).get();
		
		currentBooking.setDuration(duration);
		
		int vehicleCost =  this.ticketservice.getTicketCost(currentBooking.getTicket_type());
		
		int cost = duration*vehicleCost;
		
		currentBooking.setCost(String.valueOf(cost));
		
		this.bookingsrepo.save(currentBooking);
		slotservice.rollbackSlot(currentBooking.getSlotid());
		
		return true;
	
	}

	public String[] getDate() {
		SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy");
        Date date = new Date();
        sd.setTimeZone(TimeZone.getTimeZone("IST"));
        String time = sd.format(date);
        String[] datearr = time.split("-");
        return (datearr);
	}
	
	public String[] getTime() {
		SimpleDateFormat sd = new SimpleDateFormat("HH:mm");
        Date date = new Date();
        sd.setTimeZone(TimeZone.getTimeZone("IST"));
        String time = sd.format(date);
        String[] timearr = time.split(":");
        return (timearr);
	}
	
	public String[] splitDate(String date) {
		return date.split("-");
	}
	
	public String[] splittime(String time) {
		return  time.split(":");
	}
	
	public int getDuration(String[] time1,String[] time2, String[] date1, String[] date2) {
		//int d1 = Integer.parseInt(date1[0]);
		//int d2 = Integer.parseInt(date2[0]);
		//int t1 = Integer.parseInt(time1[0]);
		//int t2 = Integer.parseInt(time2[0]);
		//int time = Math.abs(d1-d2) * 24;
		
		//return Math.abs(t1-t2) + time;
		return 10;
	}

	@Override
	public List<Bookings> listByslotid(String slotid,String date) {
		// TODO Auto-generated method stub
		return this.bookingsrepo.findByslotid(slotid,date);
	}

	@Override
	public List<Bookings> listBymovieid(int movieid, String date) {
		// TODO Auto-generated method stub
		return this.bookingsrepo.findBymovieid(movieid, date);
	}
}
