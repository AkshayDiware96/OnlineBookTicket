package com.OTBS.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.OTBS.model.Movies;

public interface MoviesRepo extends JpaRepository<Movies, Integer>{

	
	@Query("Select count(*) from Movies where movie_name = ?1")
	int findCountOfMovie(String name);
	
	@Query("Select movie_id from Movies where movie_name = ?1")
	int getMovieId(String name);
	
	
	@Modifying
	@Transactional
	@Query("Update Movies m set m.slots = m.slots+1 where m.movie_id = ?1")
	int updateSlot(int movieid);
	
	@Query("Select s from Movies s where s.movie_id = ?1")
	Movies findBymovie_id(int id);
	
	@Modifying
	@Transactional
	@Query("Update Movies m set m.slots = m.slots-1 where m.movie_id = ?1")
	void deductslot(int id);
	
	
	
}