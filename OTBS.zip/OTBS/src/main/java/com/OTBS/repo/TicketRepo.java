package com.OTBS.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.OTBS.model.Ticket;

public interface TicketRepo  extends JpaRepository<Ticket, String>{

	@Query("Select cost from Ticket where ticket_type = ?1")
	String getTicketCost(String vehicle_type);
	
	
}
