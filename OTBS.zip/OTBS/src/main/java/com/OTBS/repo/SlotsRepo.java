package com.OTBS.repo;

import java.util.List;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.OTBS.model.Slots;

public interface SlotsRepo extends JpaRepository<Slots, String> {

	@Query("Select s from Slots s where s.movie_id = ?1")
	List<Slots> slotById(int locationid);
	
	@Modifying
	@Transactional
	@Query("Update Slots s set s.status = ?1, s.duration = ?2 where s.slotid = ?3")
	int updateSlot(int status, int duration, String slotid);
	
	@Modifying
	@Transactional
	@Query("Update Slots s set s.status = 0, s.duration = 0 where s.slotid = ?1")
	int rollbackSlot(String slotid);
	
	

}
