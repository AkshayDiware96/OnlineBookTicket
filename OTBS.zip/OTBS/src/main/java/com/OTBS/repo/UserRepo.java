package com.OTBS.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.OTBS.model.user;

public interface UserRepo extends JpaRepository<user, Integer>{
	
	public user findByUsername(String username);
	
	public user findByUid(int id);

}
