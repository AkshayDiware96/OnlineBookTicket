package com.OTBS.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.OTBS.model.Bookings;
import com.OTBS.model.Movies;

public interface BookingsRepo extends JpaRepository<Bookings, Integer> {
	
	@Query("Select b from Bookings b where email = ?1")
	List<Bookings> listByUsers(String email);
	
	@Modifying
	@Transactional
	@Query("Update Bookings b set b.paid = 1 where b.bookingid = ?1")
	int endBooking(Integer bookingid);
	

	@Query("Select b from Bookings b where b.slotid = ?1 and b.date=?2")
	List<Bookings> findByslotid(String id,String date);
	
	@Query("Select b from Bookings b where b.movie_id = ?1 and b.date=?2")
	List<Bookings> findBymovieid(int id,String date);
	

}
