package com.OTBS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OTBS.Service.TicketService;
import com.OTBS.model.Ticket;

@RestController
@CrossOrigin("*")
public class TicketController {
	
	@Autowired
	private TicketService ticketservice;
	
	@GetMapping("/ticket")
	public List<Ticket> list(){
		return this.ticketservice.listAll();
	}
	
	@PostMapping("/ticket/add")
	public ResponseEntity<Ticket> add(@RequestBody Ticket ticket){
		return new ResponseEntity<Ticket>(this.ticketservice.add(ticket),HttpStatus.OK);
	}

}
