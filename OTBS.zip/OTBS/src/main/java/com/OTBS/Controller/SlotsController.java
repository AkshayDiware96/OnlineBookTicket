package com.OTBS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OTBS.Service.SlotsService;
import com.OTBS.model.Slots;

@RestController
@CrossOrigin("*")
public class SlotsController {

@Autowired
private SlotsService service;
	
	@GetMapping("/slots")
	public List<Slots> listAll(){
		return service.listAll();
	}
	
	@GetMapping("/slots/getbyid/{movieid}")
	public List<Slots> slotById(@PathVariable("movieid") int locationid){
		return service.slotById(locationid);
		
	}
	
	@PostMapping("/slots/add")
	public boolean add(@RequestBody Slots slot) {
		return service.add(slot);
	}
	
	@DeleteMapping("/slots/deletebyid/{id}")
	public void deleteslot(@PathVariable("id") String id) {
		this.service.deleteslot(id);
	}

}
