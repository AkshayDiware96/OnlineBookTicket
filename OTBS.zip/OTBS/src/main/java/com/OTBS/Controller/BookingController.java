package com.OTBS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OTBS.Service.BookingsService;
import com.OTBS.model.Bookings;

@RestController
@CrossOrigin("*")
public class BookingController {
	
	@Autowired
	private BookingsService service;
	
	@PostMapping("/bookings/add")
	public Bookings add(@RequestBody Bookings booking) {
		 return service.add(booking);
	}
	
	@GetMapping("/bookings")
	public List<Bookings> listAll(){
		return service.listAll();
	}
	
	@GetMapping("bookings/getByUser/{email}")
	public List<Bookings> listByUsers(@PathVariable String email){
		return service.listByUsers(email);
	}
	
	@GetMapping("/bookings/endBooking/{bookingid}")
	public boolean endBooking(@PathVariable Integer bookingid) {
		return service.endBooking(bookingid);
	}
	
	@GetMapping("/bookings/allBookings")
	public List<Bookings> allBookings(){
		return service.listAll();
	}
	
	@GetMapping("bookings/getByslotid/{slotid}/{date}")
	public List<Bookings> listByslotid(@PathVariable String slotid,@PathVariable String date){
		return service.listByslotid(slotid,date);
	}
	
	@GetMapping("bookings/getBymovieid/{num}/{sdate}")
	public List<Bookings> listBymovieid(@PathVariable int num,@PathVariable String sdate){
		return service.listBymovieid(num,sdate);
	}

}
