package com.OTBS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.OTBS.Service.UserService;
import com.OTBS.model.user;

@RestController
@RequestMapping(value="/user")
@CrossOrigin("*")
public class UserController {
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private UserService userservice;
	
	@PostMapping("/")
	public boolean createuser(@RequestBody user user) {
		user.setPassword(this.bCryptPasswordEncoder.encode(user.getPassword()));
		
		return this.userservice.createuser(user);
		
	}
	
	@GetMapping("/{username}")
	public user getuser(@PathVariable("username") String username) {
		return this.userservice.getuser(username);
		
	}
	
	@DeleteMapping("/{uid}")
	public void deleteuser(@PathVariable("uid") int id) {
		this.userservice.deleteuser(id);
	}

	
	@GetMapping("/all")
	public List<user> getalluser(){
		return this.userservice.getalluser();
		
	}
	
	@PutMapping("/update/")
	public user updateuser(@RequestBody user user) {
		return this.userservice.updateuser(user);
		
	}
	
	@GetMapping("/byid/{uid}")
	public user getuserbyid(@PathVariable("uid") int id) {
			return this.userservice.getuserbyid(id);
	}
	
	/*
	 * @GetMapping("/{username}") public user
	 * getCurrentuser(@PathVariable("username") String username) { return
	 * this.userservice.getCurrentUser(username); }
	 */
}
