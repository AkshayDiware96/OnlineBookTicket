package com.OTBS.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OTBS.imp.UserDetailsServiceImpl;
import com.OTBS.model.JwtRequest;
import com.OTBS.model.JwtResponse;
import com.OTBS.security.JwtUtil;


@RestController
@CrossOrigin("*")
public class AuthController {


	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@PostMapping("/generate-token")
	public JwtResponse authenticate(@RequestBody JwtRequest cred) throws Exception{
	
		
		try {
			System.out.println("cred "+cred.getUsername());
			
			authenticationManager.authenticate(new
					 UsernamePasswordAuthenticationToken(cred.getUsername(),cred.getPassword()));
		}
		 catch(BadCredentialsException e) {
			 throw new Exception("Invalid_Credential",e);
		 }
		
		final UserDetails userDetails=userDetailsServiceImpl.loadUserByUsername(cred.getUsername());
		final String token =jwtUtil.generateToken(userDetails);
		
		return new JwtResponse(token);
		
	}
	
	


}
