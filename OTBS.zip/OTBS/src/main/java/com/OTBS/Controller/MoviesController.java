package com.OTBS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OTBS.Service.MoviesService;
import com.OTBS.model.Movies;


@RestController
@CrossOrigin("*")
public class MoviesController {

@Autowired
private MoviesService moviesservice;

@GetMapping("/locations")
public List<Movies> list(){
	return this.moviesservice.listAll();
}

@GetMapping("/locations/{movie_id}")
public Movies moviebyid(@PathVariable("movie_id") int movie_id){
	return this.moviesservice.getmovie(movie_id);
}

@PostMapping("/locations/add")
public boolean add(@RequestBody Movies movie) {
	return this.moviesservice.addMovie(movie);
}

@PutMapping("/locations/update/")
public Movies updateemp(@RequestBody Movies m) {
	return this.moviesservice.updatemovie(m);
}

}
