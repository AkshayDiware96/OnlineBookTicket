package com.OTBS.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.OTBS.model.Ticket;


public interface TicketService {
	


	public List<Ticket> listAll();
	
	public Ticket add(Ticket ticket);
	
	public int getTicketCost(String ticket_type);

}
