package com.OTBS.Service;

import java.util.List;

import com.OTBS.model.Bookings;
import com.OTBS.model.Slots;

public interface SlotsService {


	public List<Slots> listAll();
	
	public boolean add(Slots slot);
	
	public List<Slots> slotById(int movieid);
	
	public void updateSlot(Bookings booking);
	
	public void rollbackSlot(String slotid);
	
	public void deleteslot(String id);
	
}
