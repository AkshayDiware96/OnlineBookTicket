package com.OTBS.Service;

import java.util.List;

import com.OTBS.model.Movies;

public interface MoviesService {

	public List<Movies> listAll();
	
	public boolean addMovie(Movies movie);
	
	public void addSlot(int movieid) ;
	
	public Movies getmovie(int movieid);
	
	public Movies updatemovie(Movies m) ;
	
	public void reduceslot(String id);

}
