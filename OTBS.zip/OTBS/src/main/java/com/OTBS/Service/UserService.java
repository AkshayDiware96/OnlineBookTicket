package com.OTBS.Service;

import java.util.List;

import com.OTBS.model.user;

public interface UserService {
	
	public boolean createuser(user user);
	
	public user getuser(String username);
	
	public List<user> getalluser();
	
	public void deleteuser(int uid);
	
	public user updateuser(user user);
	
	public user getuserbyid(int uid);
	
	public user getCurrentUser(String username);
	
	
	
	

}
