package com.OTBS.Service;

import java.util.List;

import com.OTBS.model.Bookings;

public interface BookingsService {
	
	public Bookings add(Bookings booking);
	
	public List<Bookings> listAll();
	
	public List<Bookings> listByUsers(String email);
	
	public boolean endBooking(int bookingid);
	
	public List<Bookings> listByslotid(String slotid,String date);
	
	public List<Bookings> listBymovieid(int movieid,String date);
	

}
